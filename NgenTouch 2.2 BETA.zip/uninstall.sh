#!/bin/sh
settings put global animator_duration_scale 1.0
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0
settings delete secure multi_press_timeout
settings delete secure long_press_timeout
settings delete global block_untrusted_touches
rm -rf /sdcard/Android/ngentouch.txt
cmd notification post -S bigtext -t 'NgenTouch Uninstaller' 'Tag' 'Cleanup Done.'
exit 0